// Task 1: Translate the story into code.
